void start_menu();
